package com.example.yourlastname_mvvm.view;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.yourlastname_mvvm.R;
import com.example.yourlastname_mvvm.adapter.ProductAdapter;
import com.example.yourlastname_mvvm.viewmodel.ProductViewModel;

public class MainActivity extends AppCompatActivity {

    private ProductViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        viewModel = new ViewModelProvider(this).get(ProductViewModel.class);

        viewModel.getProducts().observe(this, products -> {
            ProductAdapter adapter = new ProductAdapter(products);
            recyclerView.setAdapter(adapter);
        });
    }
}


