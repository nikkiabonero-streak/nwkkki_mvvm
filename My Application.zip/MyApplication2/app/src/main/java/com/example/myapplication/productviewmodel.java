package com.example.yourlastname_mvvm.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.yourlastname_mvvm.model.Product;

import java.util.ArrayList;
import java.util.List;

public class ProductViewModel extends ViewModel {

    private MutableLiveData<List<Product>> productList;

    public LiveData<List<Product>> getProducts() {
        if (productList == null) {
            productList = new MutableLiveData<>();
            loadProducts();
        }
        return productList;
    }

    private void loadProducts() {
        List<Product> products = new ArrayList<>();
        products.add(new Product("Wireless Headphones", 1299));
        products.add(new Product("Smart Watch", 2499));
        products.add(new Product("Bluetooth Speaker", 999));
        products.add(new Product("Gaming Mouse", 799));

        productList.setValue(products);
    }
}
